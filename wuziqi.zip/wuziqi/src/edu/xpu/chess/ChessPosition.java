package edu.xpu.chess;

//新建一个棋子类ChessPosition保存每一步棋子所在的位置
public class ChessPosition {
    public int Listi,Listj;

    public ChessPosition() {

    }
    public ChessPosition(int Listi,int Listj) {
        this.Listi=Listi;
        this.Listj=Listj;
    }
}
